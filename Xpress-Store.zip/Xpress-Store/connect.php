<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $mobile = $_POST['mobile'];
    $gender = $_POST['gender'];

    // Establishing database connection
    $conn = new mysqli('localhost', 'root', '', 'sign');

    // Check if the connection is successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $sql = "INSERT INTO dataa (name, email, password, confirm_password, mobile, gender) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Bind parameters and execute the statement
    $stmt->bind_param("ssssss", $name, $email, $password, $cpassword, $mobile, $gender);
    $stmt->execute();

    // Check if the data was inserted successfully
    if ($stmt->affected_rows > 0) {
        echo "Data Inserted Successfully";
    } else {
        echo "Error inserting data: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
